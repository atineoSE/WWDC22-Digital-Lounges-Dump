import AVFoundation
import UIKit

public class AVPlayerView: UIView {
    
    public override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
    
    public var playerLayer: AVPlayerLayer {
        return layer as! AVPlayerLayer
    }

    public private(set) var player: AVPlayer? {
        set { playerLayer.player = newValue }
        get { return playerLayer.player }
    }
    
    private var playerItemStatusObserver: NSKeyValueObservation?

    private(set) var playerItem: AVPlayerItem? = nil {
        didSet {
            setupLooping()
        }
    }
    
    public func loadPlayerItem(_ playerItem: AVPlayerItem, onReady: ((Result<AVPlayer, Error>) -> Void)? = nil) {
        
        let player = AVPlayer(playerItem: playerItem)
        self.player = player
        self.playerItem = playerItem

        guard let completion = onReady else {
            playerItemStatusObserver = nil
            return
        }

        playerItemStatusObserver = playerItem.observe(\.status) { [weak self] item, _ in
            switch item.status {
            case .failed:
                completion(.failure(item.error!))
            case .readyToPlay:
                completion(.success(player))
                // Stop observing
                self?.playerItemStatusObserver = nil
            case .unknown:
                break
            @unknown default:
                fatalError()
            }
        }
    }
    
    public var isLoopingEnabled: Bool = false {
        didSet { setupLooping() }
    }
    
    private var didPlayToEndTimeObsever: NSObjectProtocol? = nil {
        willSet(newObserver) {
            // When updating didPlayToEndTimeObserver,
            // automatically remove its previous value from the Notification Center
            if let observer = didPlayToEndTimeObsever, didPlayToEndTimeObsever !== newObserver {
                NotificationCenter.default.removeObserver(observer)
            }
        }
    }
    
    private func setupLooping() {
        guard let playerItem = self.playerItem, let player = self.player else {
            return
        }
        
        guard isLoopingEnabled else {
            didPlayToEndTimeObsever = nil
            return
        }
        
        didPlayToEndTimeObsever = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: playerItem, queue: nil, using: { _ in
                player.seek(to: CMTime.zero) { _ in
                    player.play()
                }
        })
    }
}
