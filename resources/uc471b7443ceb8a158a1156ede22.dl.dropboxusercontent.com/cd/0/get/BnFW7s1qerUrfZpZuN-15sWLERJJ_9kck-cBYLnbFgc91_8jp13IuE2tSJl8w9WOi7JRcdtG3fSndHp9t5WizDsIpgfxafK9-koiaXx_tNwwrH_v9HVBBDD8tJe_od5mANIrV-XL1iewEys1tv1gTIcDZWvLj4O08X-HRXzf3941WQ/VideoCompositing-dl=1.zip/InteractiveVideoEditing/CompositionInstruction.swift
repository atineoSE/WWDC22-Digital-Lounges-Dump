
import UIKit
import AVFoundation
class CompositionInstruction: NSObject, AVVideoCompositionInstructionProtocol {

    var exposureAdjustment: Float = 0.0
        
    var timeRange: CMTimeRange
    var enablePostProcessing: Bool = true
    var containsTweening: Bool = false
    var requiredSourceTrackIDs: [NSValue]?
    var passthroughTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid
    
    init(timeRange: CMTimeRange, exposure: Float) {
        self.timeRange = timeRange
        self.exposureAdjustment = exposure
    }
}

