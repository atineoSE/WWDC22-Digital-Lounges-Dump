import UIKit
import AVFoundation

class VideoCompositor: NSObject, AVVideoCompositing {
    
    let renderQueue = DispatchQueue.init(label: "com.haiper.renderQueue")
    var renderContext: AVVideoCompositionRenderContext!
    let context = CIContext()
    
    var sourcePixelBufferAttributes: [String : Any]? = ["\(kCVPixelBufferPixelFormatTypeKey)": kCVPixelFormatType_32BGRA]
    var requiredPixelBufferAttributesForRenderContext: [String : Any] = ["\(kCVPixelBufferPixelFormatTypeKey)": kCVPixelFormatType_32BGRA]
    
    func renderContextChanged(_ newRenderContext: AVVideoCompositionRenderContext) {
        renderQueue.sync {
            self.renderContext = newRenderContext
        }
    }
        
    func startRequest(_ request: AVAsynchronousVideoCompositionRequest) {
        autoreleasepool {
            self.renderQueue.async {
                let instruction = request.videoCompositionInstruction as! CompositionInstruction
                
                let pixelBuffer = self.renderContext.newPixelBuffer()!
                
                let stackedRGBABuffer = request.sourceFrame(byTrackID: request.sourceTrackIDs[0].int32Value)!
                let backgroundBuffer = request.sourceFrame(byTrackID: request.sourceTrackIDs[1].int32Value)!

                // Combine rgb and alpha
                let combineRGBAFilter = CombineStackedRGBandAlphaFilter()
                combineRGBAFilter.inputImage = CIImage(cvPixelBuffer: stackedRGBABuffer)
                let sourceImage = combineRGBAFilter.outputImage!
            
                // Apply exposure adjustment to foreground video
                let exposureFilter = CIFilter(name: "CIExposureAdjust", parameters: [
                    kCIInputImageKey: sourceImage,
                    kCIInputEVKey: instruction.exposureAdjustment
                ])!
                let adjustedForegroundImage = exposureFilter.outputImage!

                let combinedImage = adjustedForegroundImage.composited(over: CIImage(cvPixelBuffer: backgroundBuffer))
                                    
                // Get the pixelBuffer from outputImage
                self.context.render(combinedImage, to: pixelBuffer)
                request.finish(withComposedVideoFrame: pixelBuffer)
            }
        }
    }
}
