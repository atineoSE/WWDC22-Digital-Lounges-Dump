import AVFoundation
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var exposureLabel: UILabel!
    @IBOutlet weak var exposureSlider: UISlider!
    @IBOutlet weak var playerView: AVPlayerView!
    
    var playerItem: AVPlayerItem!
    var customCompositionInstruction: CompositionInstruction!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup our playerLayer to hold a pixel buffer format with "alpha"
        let playerLayer: AVPlayerLayer = playerView.playerLayer
        playerLayer.videoGravity = .resizeAspect
        playerLayer.pixelBufferAttributes = [
            (kCVPixelBufferPixelFormatTypeKey as String): kCVPixelFormatType_32BGRA
        ]
    
        let foregroundMovieURL: URL = Bundle.main.url(forResource: "playdoh-bat", withExtension: "mp4")!
        let backgroundMovieURL: URL = Bundle.main.url(forResource: "background", withExtension: "mp4")!
        let playerItem = setupPlayerItem(foregroundMovieURL: foregroundMovieURL,
                                               backgroundURL: backgroundMovieURL)
        // Setup looping on our video
        playerView.isLoopingEnabled = true
        playerView.loadPlayerItem(playerItem) { result in
            switch result {
            case .failure(let error):
                print("Something went wrong when loading our video", error)
            case .success(let player):
                player.play()
            }
        }
        updateExposureValueLabel()
    }
    
    
    func setupPlayerItem(foregroundMovieURL: URL, backgroundURL: URL) -> AVPlayerItem {
        let asset = AVAsset(url: foregroundMovieURL)
        let backgroundAsset = AVAsset(url: backgroundURL)
        let mutableComposition = AVMutableComposition()
        // Set duration base on the origin model asset
        let duration:CMTime = asset.duration
        // Add model video track and background video track to same composition
        addVideoTrack(for: asset, to: mutableComposition, duration: duration)
        addVideoTrack(for: backgroundAsset, to: mutableComposition, duration: duration)
        let playerItem = AVPlayerItem(asset: mutableComposition)
        playerItem.seekingWaitsForVideoCompositionRendering = true
        playerItem.videoComposition = createVideoComposition(for: asset)
        
        return playerItem
    }
    
    func createVideoComposition(for modelAsset: AVAsset) -> AVVideoComposition {
        let composition = AVMutableVideoComposition()
        composition.customVideoCompositorClass = VideoCompositor.self
        composition.frameDuration = CMTimeMake(value: 1, timescale: 30)
        composition.renderSize = modelAsset.tracks(withMediaType: .video).first!.naturalSize.applying(CGAffineTransform(scaleX: 1.0, y: 0.5))
        let instructionTimeRange = CMTimeRangeMake(start: CMTime.zero, duration: modelAsset.duration)
        customCompositionInstruction = CompositionInstruction(timeRange: instructionTimeRange, exposure: exposureSlider.value)
        composition.instructions = [customCompositionInstruction]
        
        return composition
    }
    
    func addVideoTrack(for asset: AVAsset, to composition: AVMutableComposition, duration: CMTime) {
        let assetTrack = asset.tracks(withMediaType: .video).first!
        let compositionTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)!
        try! compositionTrack.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of:assetTrack , at: .zero)
    }
        
    @IBAction func exposureSliderChanged(_ sender: Any) {
        customCompositionInstruction.exposureAdjustment = exposureSlider.value
        updateExposureValueLabel()
    }
    
    func updateExposureValueLabel() {
        exposureLabel.text = String(format: "%0.2f", exposureSlider.value)
    }

}
