//
//  ChromaKeyFilter.swift
//  MyTransparentVideoExample
//
//  Created by Quentin on 27/10/2017.
//  Copyright © 2017 Quentin Fasquel. All rights reserved.
//

import CoreImage

final class CombineStackedRGBandAlphaFilter: CIFilter {
    
    var inputImage: CIImage?
    
    override var outputImage: CIImage? {
        // Output is nil if an input image and a mask image aren't provided
        guard let inputImage = inputImage else { return nil }

        let outputExtent = inputImage.extent.applying(CGAffineTransform(scaleX: 1.0, y: 0.5))

        // Get the top region according to Core Image coordinate system, (0,0) being bottom left
        let translate = CGAffineTransform(translationX: 0, y: outputExtent.height)
        let topRegion = outputExtent.applying(translate)
        var rgbImage = inputImage.cropped(to: topRegion)
        // Translate topImage back to origin
        rgbImage = rgbImage.transformed(by: translate.inverted())

        let bottomRegion = outputExtent
        let maskImage = inputImage.cropped(to: bottomRegion)

        let filter = CIFilter(name: "CIBlendWithMask")!
        let backgroundImage = CIImage(color: .clear).cropped(to: outputExtent)
        filter.setValue(backgroundImage, forKey: kCIInputBackgroundImageKey)
        filter.setValue(rgbImage, forKey: kCIInputImageKey)
        filter.setValue(maskImage, forKey: kCIInputMaskImageKey)
        return filter.outputImage
    }
}
